<?php
 if (!defined('BASEPATH'))
 	exit('No direct script access allowed');

class TransactionModel extends CI_Model {

	function buyCheckout($data){
		$this->db->insert('tb_transaction', $data);
		return $this->db->insert_id();
	}
	function buyCheckoutItems($data){
		$this->db->insert('tb_transaction_items', $data);
	}
	function sellCheckout($data){
		$this->db->insert('tb_transaction_sell', $data);
		return $this->db->insert_id();
	}
	function sellCheckoutItems($data){
		$this->db->insert('tb_transaction_items_sell', $data);
	}
	function lastData($year){
		$query = $this->db->query("SELECT a.t_id
		FROM tb_transaction a
		WHERE YEAR(a.t_date_created) = '$year'
		ORDER BY a.t_id DESC
		LIMIT 1");
		return $query;
	}
	function lastDataSell($year){
		$query = $this->db->query("SELECT a.t_id
		FROM tb_transaction_sell a
		WHERE YEAR(a.t_date_created) = '$year'
		ORDER BY a.t_id DESC
		LIMIT 1");
		return $query;
	}
	function buyTransaction($dateStart, $dateEnd){
		if(!empty($dateStart) && !empty($dateEnd)){
			$query = $this->db->query("SELECT a.*, b.u_name as nameCreator, c.u_name as nameReceive, d.c_name as nameCustomer
			FROM tb_transaction a
			LEFT OUTER JOIN tb_user b
			ON a.t_created_by = b.u_id
			LEFT OUTER JOIN tb_user c
			ON a.t_receive_by = c.u_id
			LEFT OUTER JOIN tb_customer d
			ON a.t_customer = d.c_id
			WHERE a.t_visible=1 AND DATE(a.t_date_created) >= '$dateStart' AND DATE(a.t_date_created) <= '$dateEnd' 
			ORDER BY a.t_id DESC");
		}else{
			$query = $this->db->query("SELECT a.*, b.u_name as nameCreator, c.u_name as nameReceive, d.c_name as nameCustomer
			FROM tb_transaction a
			LEFT OUTER JOIN tb_user b
			ON a.t_created_by = b.u_id
			LEFT OUTER JOIN tb_user c
			ON a.t_receive_by = c.u_id
			LEFT OUTER JOIN tb_customer d
			ON a.t_customer = d.c_id
			WHERE a.t_visible=1 
			ORDER BY a.t_id DESC");
		}
		return $query;
	}
	function sellTransaction($dateStart, $dateEnd){
		if(!empty($dateStart) && !empty($dateEnd)){
			$query = $this->db->query("SELECT a.*, b.u_name as nameCreator, c.u_name as nameReceive, d.c_name as nameCustomer
			FROM tb_transaction_sell a
			LEFT OUTER JOIN tb_user b
			ON a.t_created_by = b.u_id
			LEFT OUTER JOIN tb_user c
			ON a.t_receive_by = c.u_id
			LEFT OUTER JOIN tb_customer d
			ON a.t_customer = d.c_id
			WHERE a.t_visible=1 AND DATE(a.t_date_created) >= '$dateStart' AND DATE(a.t_date_created) <= '$dateEnd' 
			ORDER BY a.t_id DESC");
		}else{
			$query = $this->db->query("SELECT a.*, b.u_name as nameCreator, c.u_name as nameReceive, d.c_name as nameCustomer
			FROM tb_transaction_sell a
			LEFT OUTER JOIN tb_user b
			ON a.t_created_by = b.u_id
			LEFT OUTER JOIN tb_user c
			ON a.t_receive_by = c.u_id
			LEFT OUTER JOIN tb_customer d
			ON a.t_customer = d.c_id
			WHERE a.t_visible=1  
			ORDER BY a.t_id DESC");
		}
		return $query;
	}
	function sellDeleteTransaction($idTransaction){
		$query = $this->db->query("UPDATE
		tb_transaction_sell a
		SET a.t_visible=0
		WHERE a.t_id='$idTransaction'");
		return $query;
	}
	function buyTransactionGraph($year,$material){
		$query = $this->db->query("SELECT *
			FROM
			(SELECT *
			FROM tb_month) x
			LEFT OUTER JOIN
			(SELECT a.m_id, SUM(b.ti_price_total) as priceTotal
			FROM tb_month a
			LEFT OUTER JOIN tb_transaction_items b
			ON a.m_id = MONTH(b.ti_date_created)
			WHERE b.ti_material LIKE '%$material%' AND YEAR(b.ti_date_created) LIKE '%$year%'
			GROUP BY a.m_name) y
			ON x.m_id = y.m_id");
		return $query;
	}
	function buyTransactionCustomerGraph($year){
		$query = $this->db->query("SELECT * FROM
		(SElECT a.m_id, a.m_name as month
		FROM tb_month a) a
		LEFT OUTER JOIN
		(SELECT COUNT(DISTINCT a.t_customer) countTransaction,c.m_id, YEAR(a.t_date_created) as year
		FROM tb_transaction a
		LEFT OUTER JOIN tb_customer b
		ON a.t_customer = b.c_id
		LEFT OUTER JOIN tb_month c
		ON MONTH(a.t_date_created) = c.m_id  AND YEAR(a.t_date_created) LIKE '%$year%') b
		ON a.m_id = b.m_id");
		return $query;
	}
	function sellTransactionGraph($year,$material){
		$query = $this->db->query("SELECT *
			FROM
			(SELECT *
			FROM tb_month) x
			LEFT OUTER JOIN
			(SELECT a.m_id, SUM(b.ti_price_total) as priceTotal
			FROM tb_month a
			LEFT OUTER JOIN tb_transaction_items_sell b
			ON a.m_id = MONTH(b.ti_date_created)
			WHERE b.ti_material LIKE '%$material%' AND YEAR(b.ti_date_created) LIKE '%$year%'
			GROUP BY a.m_name) y
			ON x.m_id = y.m_id");
		return $query;
	}
	function sellTransactionCustomerGraph($year){
		$query = $this->db->query("SELECT * FROM
		(SElECT a.m_id, a.m_name as month
		FROM tb_month a) a
		LEFT OUTER JOIN
		(SELECT COUNT(DISTINCT a.t_customer) countTransaction,c.m_id, YEAR(a.t_date_created) as year
		FROM tb_transaction_sell a
		LEFT OUTER JOIN tb_customer b
		ON a.t_customer = b.c_id
		LEFT OUTER JOIN tb_month c
		ON MONTH(a.t_date_created) = c.m_id  AND YEAR(a.t_date_created) LIKE '%$year%') b
		ON a.m_id = b.m_id");
		return $query;
	}
	function buyDeleteTransaction($idTransaction){
		$query = $this->db->query("UPDATE
		tb_transaction a
		SET a.t_visible=0
		WHERE a.t_id='$idTransaction'");
		return $query;
	}
	function buyTransactionData($idTransaction){
		$query = $this->db->query("SELECT a.*, b.u_name as nameCreator, c.u_name as nameReceive, d.c_name as nameCustomer, d.*
		FROM tb_transaction a
		LEFT OUTER JOIN tb_user b
		ON a.t_created_by = b.u_id
		LEFT OUTER JOIN tb_user c
		ON a.t_receive_by = c.u_id
		LEFT OUTER JOIN tb_customer d
		ON a.t_customer = d.c_id
		WHERE a.t_id='$idTransaction' AND a.t_visible=1");
		return $query;
	}
	function buyTransactionItemsData($idTransaction){
		$query = $this->db->query("SELECT a.*
		FROM tb_transaction_items a
		LEFT OUTER JOIN tb_transaction b
		ON a.ti_t_id = b.t_id
		WHERE a.ti_t_id='$idTransaction'  AND b.t_visible=1");
		return $query;
	}
	function sellTransactionData($idTransaction){
		$query = $this->db->query("SELECT a.*, b.u_name as nameCreator, c.u_name as nameReceive, d.c_name as nameCustomer, d.*
		FROM tb_transaction_sell a
		LEFT OUTER JOIN tb_user b
		ON a.t_created_by = b.u_id
		LEFT OUTER JOIN tb_user c
		ON a.t_receive_by = c.u_id
		LEFT OUTER JOIN tb_customer d
		ON a.t_customer = d.c_id
		
		WHERE a.t_id='$idTransaction' AND a.t_visible=1");
		return $query;
	}
	function sellTransactionItemsData($idTransaction){
		$query = $this->db->query("SELECT a.*
		FROM tb_transaction_items_sell a
		LEFT OUTER JOIN tb_transaction_sell b
		ON a.ti_t_id = b.t_id
		WHERE a.ti_t_id='$idTransaction'  AND b.t_visible=1");
		return $query;
	}

}
?>